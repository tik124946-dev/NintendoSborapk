package com.nromaker;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Распаковка zip с игрой и поиск в нём ELF/NRO, иконки, romfs и meta.json. */
public final class GameZip {

    public interface Counter { void onFiles(int count); }

    public static final class Found {
        public File binary;          // main.elf или .nro
        public boolean binaryIsNro;
        public File icon;            // icon.png / icon.jpg
        public File romfsDir;        // папка romfs/ внутри архива
        public File looseRoot;       // если romfs/ нет: папка рядом с бинарником
        public Set<File> looseExclude = new HashSet<>();
        public int looseFiles;
        public boolean engineMode;   // нет ELF/NRO, но есть main.lua → игра LÖVE на встроенном движке
        public File luaRoot;         // папка, где лежит main.lua
        public String name = "", author = "", version = "";
        public int totalFiles;
    }

    private GameZip() {}

    /** Распаковывает архив в dest. Защищено от zip-slip (../ и абсолютных путей). */
    public static int extract(InputStream raw, File dest, Counter counter) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(raw, StandardCharsets.UTF_8)) {
            ZipEntry e;
            byte[] buf = new byte[1 << 16];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                if (name.startsWith("__MACOSX/") || name.endsWith(".DS_Store")) continue;
                File target = new File(dest, name);
                String canon = target.getCanonicalPath();
                if (!(canon + File.separator).startsWith(destPath) && !canon.equals(destPath.substring(0, destPath.length() - 1)))
                    continue; // подозрительный путь — пропускаем
                if (e.isDirectory()) {
                    target.mkdirs();
                    continue;
                }
                File parent = target.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new BufferedOutputStream(new FileOutputStream(target), 1 << 16)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                count++;
                if (counter != null) counter.onFiles(count);
            }
        } catch (IllegalArgumentException ex) {
            throw new IOException("Не удалось прочитать имена файлов в архиве (кодировка). "
                    + "Переименуйте файлы латиницей и упакуйте заново.", ex);
        }
        return count;
    }

    private static void walk(File dir, List<File> out) {
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (f.isDirectory()) walk(f, out);
            else if (f.isFile()) out.add(f);
        }
    }

    private static boolean isUnder(File f, File dir) {
        return f.getAbsolutePath().startsWith(dir.getAbsolutePath() + File.separator);
    }

    private static String ext(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1);
    }

    private static String baseName(File f) {
        String n = f.getName();
        int i = n.lastIndexOf('.');
        return (i < 0 ? n : n.substring(0, i)).toLowerCase(Locale.ROOT);
    }

    private static int depth(File f, File root) {
        int d = 0;
        for (File p = f; p != null && !p.equals(root); p = p.getParentFile()) d++;
        return d;
    }

    private static File shallowestRomfs(File dir, File root) {
        File best = null;
        File[] list = dir.listFiles();
        if (list == null) return null;
        for (File f : list) {
            if (!f.isDirectory()) continue;
            File cand = f.getName().equalsIgnoreCase("romfs") ? f : shallowestRomfs(f, root);
            if (cand != null && (best == null || depth(cand, root) < depth(best, root))) best = cand;
        }
        return best;
    }

    public static Found scan(File root, String zipName) throws IOException {
        Found r = new Found();
        List<File> all = new ArrayList<>();
        walk(root, all);
        r.totalFiles = all.size();

        r.romfsDir = shallowestRomfs(root, root);
        List<File> others = new ArrayList<>();
        for (File f : all) if (r.romfsDir == null || !isUnder(f, r.romfsDir)) others.add(f);

        // главный бинарник: сначала ELF (самый большой), иначе NRO
        for (String want : new String[]{"elf", "nro"}) {
            File best = null;
            for (File f : others)
                if (ext(f).equals(want) && (best == null || f.length() > best.length())) best = f;
            if (best != null) { r.binary = best; r.binaryIsNro = want.equals("nro"); break; }
        }

        // нет готового бинарника — ищем игру на Lua (main.lua) для встроенного движка
        if (r.binary == null) {
            File lua = null;
            for (File f : others)
                if (f.getName().equals("main.lua") && (lua == null || depth(f, root) < depth(lua, root))) lua = f;
            if (lua != null) {
                r.engineMode = true;
                r.luaRoot = lua.getParentFile();
            }
        }

        for (File f : others) {
            String e = ext(f);
            if ((e.equals("png") || e.equals("jpg") || e.equals("jpeg")) && baseName(f).equals("icon")
                    && (r.icon == null || depth(f, root) < depth(r.icon, root))) r.icon = f;
        }

        File meta = null;
        for (File f : others) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if ((n.equals("meta.json") || n.equals("game.json") || n.equals("info.json"))
                    && (meta == null || depth(f, root) < depth(meta, root))) meta = f;
        }
        if (meta != null) {
            String json = new String(Files.readAllBytes(meta.toPath()), StandardCharsets.UTF_8);
            r.name = jsonField(json, "name");
            r.author = jsonField(json, "author");
            r.version = jsonField(json, "version");
        }
        if (r.name.isEmpty()) {
            String z = zipName == null ? "" : zipName.replaceAll("(?i)\\.zip$", "");
            r.name = !z.isEmpty() ? z : (r.binary != null ? baseName(r.binary) : "Game");
        }
        if (r.author.isEmpty()) r.author = "Unknown";
        if (r.version.isEmpty()) r.version = "1.0.0";

        // нет папки romfs — можно упаковать остальные файлы рядом с бинарником
        if (r.romfsDir == null && r.binary != null) {
            r.looseRoot = r.binary.getParentFile();
            r.looseExclude.add(r.binary.getAbsoluteFile());
            if (r.icon != null) r.looseExclude.add(r.icon.getAbsoluteFile());
            if (meta != null) r.looseExclude.add(meta.getAbsoluteFile());
            List<File> inRoot = new ArrayList<>();
            walk(r.looseRoot, inRoot);
            for (File f : inRoot) {
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (n.startsWith("readme") || n.startsWith("license")) r.looseExclude.add(f.getAbsoluteFile());
            }
            int cnt = 0;
            for (File f : inRoot) if (!r.looseExclude.contains(f.getAbsoluteFile())) cnt++;
            r.looseFiles = cnt;
        }
        return r;
    }

    private static String jsonField(String json, String key) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json);
        if (!m.find()) return "";
        return m.group(1).replace("\\\"", "\"").replace("\\\\", "\\").trim();
    }
}
