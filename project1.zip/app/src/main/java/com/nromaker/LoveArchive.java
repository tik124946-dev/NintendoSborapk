package com.nromaker;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Упаковывает папку с игрой в .love (zip), где main.lua лежит в корне архива. */
public final class LoveArchive {

    private LoveArchive() {}

    public static int pack(File root, File outFile) throws IOException {
        List<File> files = new ArrayList<>();
        collect(root, files);
        Collections.sort(files);
        String base = root.getAbsolutePath() + File.separator;
        byte[] buf = new byte[1 << 16];
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outFile), 1 << 16))) {
            z.setLevel(Deflater.DEFAULT_COMPRESSION);
            for (File f : files) {
                String rel = f.getAbsolutePath().substring(base.length()).replace(File.separatorChar, '/');
                z.putNextEntry(new ZipEntry(rel));
                try (InputStream in = new FileInputStream(f)) {
                    int n;
                    while ((n = in.read(buf)) > 0) z.write(buf, 0, n);
                }
                z.closeEntry();
            }
        }
        return files.size();
    }

    private static void collect(File dir, List<File> out) throws IOException {
        File[] list = dir.listFiles();
        if (list == null) throw new IOException("Не удалось прочитать папку " + dir);
        for (File f : list) {
            if (f.isDirectory()) collect(f, out);
            else if (f.isFile()) out.add(f);
        }
    }
}
