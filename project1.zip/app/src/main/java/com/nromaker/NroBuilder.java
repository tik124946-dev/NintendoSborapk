package com.nromaker;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Порт логики elf2nro / nacptool из devkitPro. */
public final class NroBuilder {

    private static final int PAGE = 0x1000;

    private NroBuilder() {}

    private static int align(int v, int a) { return (v + a - 1) / a * a; }

    /** ELF (aarch64, собранный через libnx: 3 сегмента PT_LOAD) -> NRO без ассетов. */
    public static byte[] elfToNro(byte[] elf) {
        if (elf.length < 0x40 || elf[0] != 0x7f || elf[1] != 'E' || elf[2] != 'L' || elf[3] != 'F')
            throw new IllegalArgumentException("Главный файл не является ELF");
        if (elf[4] != 2) throw new IllegalArgumentException("Нужен 64-битный ELF (aarch64)");
        ByteBuffer b = ByteBuffer.wrap(elf).order(ByteOrder.LITTLE_ENDIAN);
        if ((b.getShort(0x12) & 0xFFFF) != 0xB7)
            throw new IllegalArgumentException("ELF не для aarch64 (Switch)");

        int phoff = (int) b.getLong(0x20);
        int phentsize = b.getShort(0x36) & 0xFFFF;
        int phnum = b.getShort(0x38) & 0xFFFF;

        List<long[]> loads = new ArrayList<>(); // offset, vaddr, filesz, memsz
        byte[] buildId = new byte[0x20];
        for (int i = 0; i < phnum; i++) {
            int p = phoff + i * phentsize;
            int type = b.getInt(p);
            long off = b.getLong(p + 8), vaddr = b.getLong(p + 16);
            long filesz = b.getLong(p + 32), memsz = b.getLong(p + 40);
            if (off < 0 || filesz < 0 || off + filesz > elf.length)
                throw new IllegalArgumentException("Повреждённый ELF (сегмент за пределами файла)");
            if (type == 1) {
                loads.add(new long[]{off, vaddr, filesz, memsz});
            } else if (type == 4) {
                int o = (int) off, end = (int) (off + filesz);
                while (o + 12 <= end) {
                    int namesz = b.getInt(o), descsz = b.getInt(o + 4), ntype = b.getInt(o + 8);
                    int nameOff = o + 12;
                    int descOff = nameOff + align(namesz, 4);
                    if (descOff + descsz > end) break;
                    if (ntype == 3 && namesz == 4 && descsz > 0) {
                        buildId = new byte[0x20];
                        System.arraycopy(elf, descOff, buildId, 0, Math.min(descsz, 0x20));
                    }
                    o = descOff + align(descsz, 4);
                }
            }
        }
        if (loads.size() != 3)
            throw new IllegalArgumentException("Ожидалось 3 сегмента PT_LOAD (text, rodata, data), найдено "
                    + loads.size() + ". ELF собран не через libnx?");
        loads.sort((x, y) -> Long.compare(x[1], y[1]));
        long[] text = loads.get(0), ro = loads.get(1), data = loads.get(2);

        int textSz = align((int) text[2], PAGE);
        int roSz = align((int) ro[2], PAGE);
        int dataSz = align((int) data[2], PAGE);
        if (text[1] != 0 || ro[1] != textSz || data[1] != textSz + roSz)
            throw new IllegalArgumentException("Сегменты ELF лежат не подряд — нужен ELF, собранный с switch.specs");
        long memEnd = align((int) (data[1] + data[3]), PAGE);
        int bssSz = (int) Math.max(0, memEnd - (data[1] + dataSz));
        int total = textSz + roSz + dataSz;

        byte[] out = new byte[total];
        System.arraycopy(elf, (int) text[0], out, 0, (int) text[2]);
        System.arraycopy(elf, (int) ro[0], out, textSz, (int) ro[2]);
        System.arraycopy(elf, (int) data[0], out, textSz + roSz, (int) data[2]);

        ByteBuffer ob = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);
        int modOff = ob.getInt(4);
        if (modOff < 0 || modOff + 4 > total
                || !new String(out, modOff, 4, StandardCharsets.US_ASCII).equals("MOD0"))
            throw new IllegalArgumentException("MOD0 не найден: ELF собран не через libnx (switch.specs)");

        ob.position(0x10);
        ob.put("NRO0".getBytes(StandardCharsets.US_ASCII));
        ob.putInt(0);            // version
        ob.putInt(total);        // size
        ob.putInt(0);            // flags
        ob.putInt(0);          ob.putInt(textSz);
        ob.putInt(textSz);     ob.putInt(roSz);
        ob.putInt(textSz + roSz); ob.putInt(dataSz);
        ob.putInt(bssSz);
        ob.putInt(0);
        ob.put(buildId);
        return out;
    }

    /** NACP (0x4000 байт): название и автор для всех 16 языков + версия. */
    public static byte[] nacp(String name, String author, String version) {
        byte[] n = new byte[0x4000];
        byte[] nb = cut(name.getBytes(StandardCharsets.UTF_8), 0x200);
        byte[] ab = cut(author.getBytes(StandardCharsets.UTF_8), 0x100);
        for (int i = 0; i < 16; i++) {
            System.arraycopy(nb, 0, n, i * 0x300, nb.length);
            System.arraycopy(ab, 0, n, i * 0x300 + 0x200, ab.length);
        }
        byte[] vb = cut(version.getBytes(StandardCharsets.UTF_8), 0x10);
        System.arraycopy(vb, 0, n, 0x3060, vb.length);
        return n;
    }

    private static byte[] cut(byte[] s, int max) {
        // оставляем место под завершающий ноль
        return s.length < max ? s : Arrays.copyOf(s, max - 1);
    }

    /**
     * Пишет NRO + блок ASET (иконка, NACP, RomFS) в поток.
     * Если в baseNro уже были ассеты, они отбрасываются.
     */
    public static void write(byte[] baseNro, byte[] nacp, byte[] icon, RomFs romfs,
                             OutputStream out, RomFs.Progress progress) throws IOException {
        if (baseNro.length < 0x80
                || !new String(baseNro, 0x10, 4, StandardCharsets.US_ASCII).equals("NRO0"))
            throw new IllegalArgumentException("Главный файл не является NRO");
        int size = ByteBuffer.wrap(baseNro).order(ByteOrder.LITTLE_ENDIAN).getInt(0x18);
        if (size <= 0 || size > baseNro.length)
            throw new IllegalArgumentException("Повреждённый NRO (неверный размер в заголовке)");
        out.write(baseNro, 0, size);

        final int headerSize = 0x38;
        long off = headerSize;
        long iconOff = 0, iconSize = 0, nacpOff = 0, nacpSize = 0, romOff = 0, romSize = 0;
        if (icon != null) { iconOff = off; iconSize = icon.length; off += icon.length; }
        if (nacp != null) { nacpOff = off; nacpSize = nacp.length; off += nacp.length; }
        long pad = 0;
        if (romfs != null) {
            long aligned = (off + 0xFFF) / 0x1000 * 0x1000;
            pad = aligned - off;
            romOff = aligned;
            romSize = romfs.size();
        }

        ByteBuffer h = ByteBuffer.allocate(headerSize).order(ByteOrder.LITTLE_ENDIAN);
        h.put("ASET".getBytes(StandardCharsets.US_ASCII));
        h.putInt(0);
        h.putLong(iconOff); h.putLong(iconSize);
        h.putLong(nacpOff); h.putLong(nacpSize);
        h.putLong(romOff);  h.putLong(romSize);
        out.write(h.array());
        if (icon != null) out.write(icon);
        if (nacp != null) out.write(nacp);
        if (romfs != null) {
            out.write(new byte[(int) pad]);
            romfs.writeTo(out, progress);
        }
        out.flush();
    }

    /**
     * Режим движка: берёт готовый NRO-движок (LÖVE Potion), подменяет в нём иконку и NACP,
     * сохраняет его собственный RomFS (шейдеры и т.п.) и дописывает в конец игру в виде .love (zip).
     */
    public static void writeWithRuntime(byte[] runtime, byte[] nacp, byte[] icon, File gameLove,
                                        OutputStream out, RomFs.Progress progress) throws IOException {
        if (runtime.length < 0x80
                || !new String(runtime, 0x10, 4, StandardCharsets.US_ASCII).equals("NRO0"))
            throw new IllegalArgumentException("Встроенный движок повреждён (это не NRO)");
        ByteBuffer rb = ByteBuffer.wrap(runtime).order(ByteOrder.LITTLE_ENDIAN);
        int size = rb.getInt(0x18);
        if (size <= 0 || size > runtime.length)
            throw new IllegalArgumentException("Встроенный движок повреждён (размер в заголовке)");

        byte[] oldIcon = null, oldRomfs = null;
        if (runtime.length >= size + 0x38
                && new String(runtime, size, 4, StandardCharsets.US_ASCII).equals("ASET")) {
            long iOff = rb.getLong(size + 8), iSz = rb.getLong(size + 16);
            long rOff = rb.getLong(size + 40), rSz = rb.getLong(size + 48);
            if (iSz > 0 && size + iOff + iSz <= runtime.length)
                oldIcon = Arrays.copyOfRange(runtime, (int) (size + iOff), (int) (size + iOff + iSz));
            if (rSz > 0 && size + rOff + rSz <= runtime.length)
                oldRomfs = Arrays.copyOfRange(runtime, (int) (size + rOff), (int) (size + rOff + rSz));
        }
        if (icon == null) icon = oldIcon;

        final int headerSize = 0x38;
        long off = headerSize;
        long iconOff = 0, iconSize = 0, nacpOff = 0, nacpSize = 0, romOff = 0, romSize = 0, pad = 0;
        if (icon != null) { iconOff = off; iconSize = icon.length; off += icon.length; }
        if (nacp != null) { nacpOff = off; nacpSize = nacp.length; off += nacp.length; }
        if (oldRomfs != null) {
            long aligned = (off + 0xFFF) / 0x1000 * 0x1000;
            pad = aligned - off;
            romOff = aligned;
            romSize = oldRomfs.length;
        }

        out.write(runtime, 0, size);
        ByteBuffer h = ByteBuffer.allocate(headerSize).order(ByteOrder.LITTLE_ENDIAN);
        h.put("ASET".getBytes(StandardCharsets.US_ASCII));
        h.putInt(0);
        h.putLong(iconOff); h.putLong(iconSize);
        h.putLong(nacpOff); h.putLong(nacpSize);
        h.putLong(romOff);  h.putLong(romSize);
        out.write(h.array());
        if (icon != null) out.write(icon);
        if (nacp != null) out.write(nacp);
        if (oldRomfs != null) {
            out.write(new byte[(int) pad]);
            out.write(oldRomfs);
        }

        // игра .love — сразу после ASET, как делает апстрим: cat lovepotion.nro game.love
        long total = gameLove.length(), done = 0;
        byte[] buf = new byte[1 << 16];
        try (InputStream in = new FileInputStream(gameLove)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                if (progress != null) progress.onProgress(done, total);
            }
        }
        out.flush();
    }

    /** Удобная версия для тестов: всё в память. */
    public static byte[] writeToBytes(byte[] baseNro, byte[] nacp, byte[] icon, RomFs romfs) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        write(baseNro, nacp, icon, romfs, bos, null);
        return bos.toByteArray();
    }
}
