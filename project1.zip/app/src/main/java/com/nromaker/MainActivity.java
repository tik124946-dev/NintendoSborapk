package com.nromaker;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_ZIP = 1;
    private static final int REQ_ICON = 2;
    private static final int REQ_SAVE = 3;

    private File workDir;
    private GameZip.Found found;
    private Uri iconOverride;
    private volatile boolean busy;

    private TextView summary, status, iconLabel;
    private EditText nameEt, authorEt, versionEt;
    private CheckBox packLoose;
    private ProgressBar bar;
    private Button zipBtn, iconBtn, buildBtn;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void ui(Runnable r) { runOnUiThread(r); }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        return e;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        workDir = new File(getCacheDir(), "work");

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(24));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(col);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("NRO Maker");
        title.setTextSize(24f);
        col.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Выберите zip с игрой на Lua (LÖVE): внутри main.lua и ресурсы игры, "
                + "по желанию icon.png и meta.json (name, author, version). ELF не нужен — "
                + "приложение распакует архив и соберёт готовый .nro на встроенном движке "
                + "LÖVE Potion. (Если в zip лежит готовый .elf/.nro, соберётся из него.)");
        col.addView(hint);

        zipBtn = new Button(this);
        zipBtn.setText("1. Выбрать ZIP с игрой");
        zipBtn.setOnClickListener(v -> pick(REQ_ZIP, "*/*"));
        col.addView(zipBtn);

        summary = new TextView(this);
        summary.setText("Архив не выбран");
        col.addView(summary);

        nameEt = field("Название", "");
        authorEt = field("Автор", "");
        versionEt = field("Версия", "");
        col.addView(nameEt);
        col.addView(authorEt);
        col.addView(versionEt);

        packLoose = new CheckBox(this);
        packLoose.setText("Если папки romfs нет — положить остальные файлы рядом с ELF в romfs");
        packLoose.setChecked(true);
        col.addView(packLoose);

        iconBtn = new Button(this);
        iconBtn.setText("Заменить иконку (необязательно)");
        iconBtn.setOnClickListener(v -> pick(REQ_ICON, "image/*"));
        col.addView(iconBtn);
        iconLabel = new TextView(this);
        col.addView(iconLabel);

        buildBtn = new Button(this);
        buildBtn.setText("2. Собрать и сохранить .nro");
        buildBtn.setEnabled(false);
        buildBtn.setOnClickListener(v -> askSaveLocation());
        col.addView(buildBtn);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setVisibility(View.GONE);
        col.addView(bar);

        status = new TextView(this);
        status.setPadding(0, dp(12), 0, 0);
        col.addView(status);
    }

    private void pick(int req, String type) {
        if (busy) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, req);
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) { }
        return null;
    }

    private void setBusy(boolean b) {
        busy = b;
        zipBtn.setEnabled(!b);
        iconBtn.setEnabled(!b);
        buildBtn.setEnabled(!b && found != null && (found.binary != null || found.engineMode));
        bar.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private void fail(Throwable e) {
        setBusy(false);
        String m = e.getMessage();
        status.setText("Ошибка: " + (m == null ? e.getClass().getSimpleName() : m));
    }

    private static void deleteRec(File f) {
        File[] list = f.listFiles();
        if (list != null) for (File c : list) deleteRec(c);
        f.delete();
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_ZIP) onZipPicked(uri);
        else if (requestCode == REQ_ICON) {
            iconOverride = uri;
            iconLabel.setText("Иконка: " + displayName(uri));
        } else if (requestCode == REQ_SAVE) onSavePicked(uri);
    }

    private void onZipPicked(Uri uri) {
        final String zipName = displayName(uri);
        found = null;
        iconOverride = null;
        iconLabel.setText("");
        setBusy(true);
        status.setText("Распаковываю…");
        bar.setIndeterminate(true);
        new Thread(() -> {
            try {
                deleteRec(workDir);
                workDir.mkdirs();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    GameZip.extract(in, workDir, n -> {
                        if (n % 20 == 0) ui(() -> status.setText("Распаковано файлов: " + n));
                    });
                }
                final GameZip.Found f = GameZip.scan(workDir, zipName);
                ui(() -> showFound(f));
            } catch (Throwable e) {
                ui(() -> { bar.setIndeterminate(false); fail(e); });
            }
        }).start();
    }

    private void showFound(GameZip.Found f) {
        found = f;
        bar.setIndeterminate(false);
        setBusy(false);
        nameEt.setText(f.name);
        authorEt.setText(f.author);
        versionEt.setText(f.version);

        StringBuilder sb = new StringBuilder();
        sb.append("Файлов в архиве: ").append(f.totalFiles).append('\n');
        boolean ok = f.binary != null || f.engineMode;
        if (f.binary != null) {
            sb.append(f.binaryIsNro ? "NRO: " : "ELF: ").append(f.binary.getName()).append('\n');
        } else if (f.engineMode) {
            sb.append("Игра LÖVE (Lua): main.lua найден, движок встроен — ELF не нужен.\n");
        } else {
            sb.append("Не найден ни main.lua, ни .elf/.nro — собрать нечего.\n");
        }
        sb.append("Иконка: ").append(f.icon != null ? f.icon.getName() : "не найдена (будет иконка движка)").append('\n');
        if (!f.engineMode) {
            if (f.romfsDir != null) sb.append("RomFS: папка romfs");
            else if (f.looseFiles > 0) sb.append("RomFS: папки romfs нет, рядом с ELF файлов: ").append(f.looseFiles);
            else sb.append("RomFS: нет");
        }
        summary.setText(sb.toString());
        status.setText(ok ? "Готово к сборке." : "");
        buildBtn.setEnabled(ok);
    }

    private void askSaveLocation() {
        if (found == null || (found.binary == null && !found.engineMode) || busy) return;
        String base = nameEt.getText().toString().trim();
        if (base.isEmpty()) base = "game";
        String file = base.replaceAll("[^A-Za-z0-9._-]", "_") + ".nro";
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, file);
        startActivityForResult(i, REQ_SAVE);
    }

    private byte[] iconJpeg(File file, Uri uri) throws Exception {
        Bitmap bmp;
        if (uri != null) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(in);
            }
        } else {
            bmp = BitmapFactory.decodeFile(file.getAbsolutePath());
        }
        if (bmp == null) throw new IllegalArgumentException("Не удалось прочитать иконку");
        Bitmap scaled = Bitmap.createScaledBitmap(bmp, 256, 256, true);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 92, bos);
        return bos.toByteArray();
    }

    /** Игра на Lua: движок LÖVE Potion из assets + игра в виде .love в конце файла. */
    private void buildWithEngine(GameZip.Found f, byte[] nacp, byte[] icon, Uri out) throws Exception {
        byte[] runtime;
        try (InputStream in = getAssets().open("lovepotion.nro")) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            runtime = bos.toByteArray();
        } catch (java.io.FileNotFoundException e) {
            throw new IllegalStateException("В приложении нет движка lovepotion.nro. "
                    + "Соберите APK через workflow из build.yml — он собирает движок сам.");
        }
        File love = new File(getCacheDir(), "game.love");
        ui(() -> status.setText("Упаковываю игру…"));
        LoveArchive.pack(f.luaRoot, love);
        ui(() -> { bar.setIndeterminate(false); status.setText("Записываю файл…"); });
        final long[] last = {0};
        try (OutputStream os = new BufferedOutputStream(
                getContentResolver().openOutputStream(out, "wt"), 1 << 16)) {
            NroBuilder.writeWithRuntime(runtime, nacp, icon, love, os, (done, total) -> {
                long now = System.currentTimeMillis();
                if (now - last[0] > 200 || done == total) {
                    last[0] = now;
                    ui(() -> bar.setProgress((int) (done * 1000 / Math.max(1, total))));
                }
            });
        }
        final long size = runtime.length + love.length();
        love.delete();
        ui(() -> {
            setBusy(false);
            status.setText(String.format(Locale.US,
                    "Готово! .nro сохранён (около %.1f МБ). Скопируйте его на SD-карту "
                            + "Switch в папку /switch/ и запустите из hbmenu.",
                    size / 1048576.0));
        });
    }

    private void onSavePicked(Uri out) {
        final GameZip.Found f = found;
        final String name = nameEt.getText().toString().trim();
        final String author = authorEt.getText().toString().trim();
        final String version = versionEt.getText().toString().trim();
        final boolean loose = packLoose.isChecked();
        final Uri iconUri = iconOverride;
        setBusy(true);
        bar.setIndeterminate(true);
        status.setText("Собираю…");
        new Thread(() -> {
            try {
                byte[] nacp = NroBuilder.nacp(name.isEmpty() ? "Game" : name,
                        author.isEmpty() ? "Unknown" : author,
                        version.isEmpty() ? "1.0.0" : version);
                byte[] icon = null;
                if (iconUri != null || f.icon != null) icon = iconJpeg(f.icon, iconUri);

                if (f.engineMode) {
                    buildWithEngine(f, nacp, icon, out);
                    return;
                }

                byte[] bin = Files.readAllBytes(f.binary.toPath());
                byte[] nro = f.binaryIsNro ? bin : NroBuilder.elfToNro(bin);

                RomFs romfs = null;
                if (f.romfsDir != null) romfs = RomFs.build(f.romfsDir, null);
                else if (loose && f.looseRoot != null) romfs = RomFs.build(f.looseRoot, f.looseExclude);
                if (romfs != null && romfs.fileCount() == 0) romfs = null;

                ui(() -> { bar.setIndeterminate(false); status.setText("Записываю файл…"); });
                final long[] last = {0};
                try (OutputStream os = new BufferedOutputStream(
                        getContentResolver().openOutputStream(out, "wt"), 1 << 16)) {
                    NroBuilder.write(nro, nacp, icon, romfs, os, (done, total) -> {
                        long now = System.currentTimeMillis();
                        if (now - last[0] > 200 || done == total) {
                            last[0] = now;
                            ui(() -> bar.setProgress((int) (done * 1000 / Math.max(1, total))));
                        }
                    });
                }
                final long size = nro.length + (romfs == null ? 0 : romfs.size());
                ui(() -> {
                    setBusy(false);
                    status.setText(String.format(Locale.US,
                            "Готово! .nro сохранён (около %.1f МБ). Скопируйте его на SD-карту "
                                    + "Switch в папку /switch/ и запустите из hbmenu.",
                            size / 1048576.0));
                });
            } catch (Throwable e) {
                ui(() -> fail(e));
            }
        }).start();
    }
}
